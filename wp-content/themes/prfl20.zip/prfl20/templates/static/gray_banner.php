<h1> Gray Banner Settings </h1>
<form >
    <label style=margin-bottom:10px; for="banner-text" > Text to display on Banner  :   </label> <br />
    <textarea type="text" name="banner-text" placeholder=" Gray Banner Text " rows=5 cols="100" ></texarea>
</form>
